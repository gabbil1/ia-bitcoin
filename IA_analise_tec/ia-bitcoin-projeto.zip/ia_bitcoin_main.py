# Aqui vai seu script principal da IA (ia_bitcoin_main.py)
print('IA Bitcoin executando...')